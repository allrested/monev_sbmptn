
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                DASHBOARD FORM INSTRUMEN MONEV HUMAS PTN SNMPTN 2017
                <small></small>
            </h1>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="col-md-12">
          <div class="box box-default collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title">A. Pengisian PDSS & SNMPTN 2017</h3></br><br>I. Sosialisasi PDSS & SNMPTN 2017</h3><br><br></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: none;">
              <div class="row">
              <h2 class="box-title"> 1. Bagaimana cara pelaksanaan sosialisasi PDSS & SNMPTN 2017 di wilayah saudara?<h2>
            <form method="post" action="<?php echo base_url()?>input/insert">
            <table class="table table-bordered" >
                    <tr>
                    <td colspan="1" rowspan="2">Aspek</td>
                    <td rowspan="1" colspan="8" align="center">Metode</td>
                    </tr>
                    <tr>
                        <td align="center">Mengundang <br>Peserta</td>
                        <td align="center">Mengunjungi <br> Sasaran</td>
                        <td align="center">Media Cetak Koran</td>
                        <td align="center">Leaflet / Pamflet</td>
                        <td align="center">Baliho / Spanduk</td>
                        <td align="center">TV</td>
                        <td align="center">Radio</td>
                        <td align="center">Lain-lain</td>
                    </tr>
                    <tr>
                    <style type="text/css">
  input[type=number]{
    width: 60px; !important
} 
</style>
                        <td>Sasaran/Peserta </td>
                        <td><input type="number" class="form-control" id="1" name="1" > &nbsp; Kepala Sekolah<br>
                          <input type="number" class="form-control" id="2"  name="2"   > &nbsp; Guru<br>
                          <input type="number" class="form-control" id="3"  name="3" > &nbsp; Siswa<br></td>
                        <td><input type="number" class="form-control" id="4"  name="4" > &nbsp; Kepala Sekolah<br>
                          <input type="number" class="form-control" id="5"  name="5" > &nbsp; Guru<br>
                          <input type="number" class="form-control" id="6"  name="6" > &nbsp; Siswa<br></td>
                        <td><input type="number" class="form-control" id="7" name="7" > &nbsp; Kepala Sekolah<br>
                          <input type="number" class="form-control"  id="8"  name="8" > &nbsp; Guru<br>
                          <input type="number" class="form-control"  id="9"  name="9" > &nbsp; Siswa<br></td>
                        <td><input type="number" class="form-control"  id="10"  name="10" > &nbsp; Kepala Sekolah<br>
                          <input type="number" class="form-control"  id="11"  name="11" > &nbsp; Guru<br>
                          <input type="number" class="form-control" id="12"   name="12" > &nbsp; Siswa<br></td>
                        <td><input type="number" class="form-control"  id="13"  name="13" > &nbsp; Kepala Sekolah<br>
                          <input type="number" class="form-control"  id="14"  name="14" > &nbsp; Guru<br>
                          <input type="number" class="form-control" id="15"   name="15" > &nbsp; Siswa<br></td>
                        <td><input type="number" class="form-control"  id="16"  name="16" > &nbsp; Kepala Sekolah<br>
                          <input type="number" class="form-control"  id="17"  name="17" > &nbsp; Guru<br>
                          <input type="number" class="form-control"  id="18"  name="18" > &nbsp; Siswa<br></td>
                        <td><input type="number" class="form-control" id="19"   name="19" > &nbsp; Kepala Sekolah<br>
                          <input type="number" class="form-control"  id="20"  name="20" > &nbsp; Guru<br>
                          <input type="number" class="form-control" id="21"   name="21" > &nbsp; Siswa<br></td>
                        <td align="center" style="vertical-align: middle;"><textarea name="222"  ></textarea></td>     
                    </tr>
                    <tr>
                        <td>Jumlah</td>
                        <td><input type="number" name="22"  id="22"  class="form-control"></td>
                        <td><input type="number" name="23"  id="23"  class="form-control"></td>
                        <td><input type="number" name="24"  id="24"  class="form-control"></td>
                        <td><input type="number" name="25"  id="25"  class="form-control"></td>
                        <td><input type="number" name="26"  id="26"  class="form-control"></td>
                        <td><input type="number" name="27"  id="27"  class="form-control"></td>
                        <td><input type="number" name="28"  id="28"  class="form-control"></td>
                     <td align="center"><textarea name="29"  ></textarea></td>
                    </tr>
                    <tr>
                        <td>Berapa Lokasi/Kota</td>
                        <td><input type="number" name="30" class="form-control"></td>
                        <td><input type="number" name="31" class="form-control">`</td>
                        <td><input type="number" name="32" class="form-control"></td>
                        <td><input type="number" name="33" class="form-control"></td>
                        <td><input type="number" name="34" class="form-control"></td>
                        <td><input type="number" name="35" class="form-control"></td>
                        <td><input type="number" name="36" class="form-control"></td>
                         <td align="center"><textarea name="37"  ></textarea></td>
                    </tr>
                     <tr>
                        <td>Diluar Ketiga Asepek Diatas</td>
                         <td align="center" colspan="8"><textarea name="38"   class="textarea form-control"></textarea></td>
                    </tr>
                </table>
            </div>
              <!-- /.row -->
            </div>
</section>
<section class="content">
            <div class="col-md-12">
          <div class="box box-default collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title">A. Pengisian PDSS & SNMPTN 2017</h3></br><br>I. Sosialisasi PDSS & SNMPTN 2017</h3><br><br></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: none;">
              <div class="row">

                   <h2 class="box-title">2. Bagaimana Tanggapan Sasaran/Peserta Terkait Pelaksanaan Sosialisasi PDSS & SNMPTN 2017</h2>
                <table class="table table-bordered">
                    <tr>
                    <td align='center' colspan="1" rowspan="2">Sasaran Peserta</td>
                    <td rowspan="1" colspan="8" align="center">Aspek </td>
                    </tr>
                    <tr>
                        <td align="center">Tidak Jelas</td>
                        <td align="center">Kurang Jelas</td>
                        <td align="center">Cukup Jelas</td>
                        <td align="center">Jelas</td>
                        <td align="center">Sangat Jelas</td>
                        <td align="center">Keterangan</td>
                        
                    </tr>
                    <tr>
                        <td>Kepala Sekolah </td>
                        <td align ='center'><input type="radio" value="1" name="39" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="2" name="39" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="3" name="39" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="4" name="39" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="5" name="39" > &nbsp; </td>
                        <td align="center"><textarea name="40"  ></textarea></td>     
                    </tr>
                    
                    <tr>
                        <td>Guru (BK)</td>
                        <td align ='center'><input type="radio" value="1" name="44" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="2" name="44" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="3" name="44" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="4" name="44" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="5" name="44" > &nbsp; </td>
                        <td align="center"><textarea name="49"  ></textarea></td>  
                    </tr>
                    <tr>
                        <td>Siswa</td>
                        <td align ='center'><input type="radio" value="1" name="50" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="2" name="50" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="3" name="50" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="4" name="50" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="5" name="50" > &nbsp; </td>
                        <td align="center"><textarea name="55"  ></textarea></td>  
                    </tr>
                     <tr>
                        <td>Orang Tua Siswa</td>
                        <td align ='center'><input type="radio" value="1" name="56" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="2" name="56" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="3" name="56" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="4" name="56" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="5" name="56" > &nbsp; </td>
                        <td align="center"><textarea name="61"  ></textarea></td>  
                    </tr> 
              

                </table>
            </div>
            </div>
            </div>
            </section>
             <section class="content">
           <div class="col-md-12">
          <div class="box box-default collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title">A. Pengisian PDSS & SNMPTN 2017</h3></br><br>I. Sosialisasi PDSS & SNMPTN 2017</h3><br><br></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
                
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: none;">
              <div class="row">
                   <h2 class="box-title">3. Apakah pada PTN saudara memiliki pusat informasi dan layanan telfon untuk PDSS dan SNMPTN 2017 ?</h2>
            
                <table class="table table-bordered">
                    <tr>
                    <td align='center' colspan="1" rowspan="2">Jenis Layanan Informasi PDSS dan SNMPTN</td>
                    <td rowspan="1" colspan="8" align="center">Aspek </td>
                    </tr>
                    <tr>
                        <td align="center">Ada</td>
                        <td align="center">Tidak Ada</td>
                        <td align="center">Keterangan</td>
                        
                    </tr>
                    <tr>
                        <td>Helpdesk </td>
                        <td align ='center'><input type="radio" value="1" name="62" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="62" > &nbsp; </td>
                       
                        <td align="center"><textarea name="63"  ></textarea></td>     
                    </tr>
                    
                    <tr>
                        <td>Telpon (call center)</td>
                        <td align ='center'><input type="radio" value="1" name="64" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="64" > &nbsp; </td>
                       
                        <td align="center"><textarea name="66"  ></textarea></td>  
                    </tr>
                    <tr>
                        <td>SMS</td>
                        <td align ='center'><input type="radio" value="1" name="67" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="67" > &nbsp; </td>

                        <td align="center"><textarea name="69"  ></textarea></td>  
                    </tr>
                     <tr>
                        <td>Twitter</td>
                        <td align ='center'><input type="radio" value="1" name="70" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="70" > &nbsp; </td>
                        <td align="center"><textarea name="72"  ></textarea></td>  
                    </tr>
                     <tr>
                        <td>Facebook</td>
                        <td align ='center'><input type="radio" value="1" name="73" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="73" > &nbsp; </td>
                        <td align="center"><textarea name="75"  ></textarea></td>  
                    </tr> 
              

                </table>
                </div>
                </div>
                </div>
                </div>
           </section>
           <section class="content">
            <div class="col-md-12">
          <div class="box box-default collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title">A. Pengisian PDSS & SNMPTN 2017</h3></br><br>I. Sosialisasi PDSS & SNMPTN 2017</h3><br><br></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: none;">
              <div class="row">
                   <h2 class="box-title">4. Kendala yang dikeluhkan oleh sekolah terkair dengan pengisian PDSS dan pendaftaran SNMPTN 2017 ?</h2>
          
                <table class="table table-bordered">
                    <tr>
                    <td align='center' colspan="1" rowspan="2">Kendala</td>
                    <td rowspan="1" colspan="8" align="center">Aspek </td>
                    </tr>
                    <tr>
                        <td align="center">Ada</td>
                        <td align="center">Tidak Ada</td>
                        <td align="center">Penyelesaian (Jika ada)</td>
                        
                    </tr>
                    <tr>
                        <td>Koneksi Internet </td>
                        <td align ='center'><input type="radio" value="1" name="76" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="76" > &nbsp; </td>
                       
                        <td align="center"><textarea name="78"  ></textarea></td>     
                    </tr>
                    
                    <tr>
                        <td>NPSN</td>
                        <td align ='center'><input type="radio" value="1" name="79" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="79" > &nbsp; </td>
                       
                        <td align="center"><textarea name="81"  ></textarea></td>  
                    </tr>
                    <tr>
                        <td>NISN</td>
                        <td align ='center'><input type="radio" value="1" name="82" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="82" > &nbsp; </td>

                        <td align="center"><textarea name="84"  ></textarea></td>  
                    </tr>
                     <tr>
                        <td>Akreditasi</td>
                        <td align ='center'><input type="radio" value="1" name="85" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="85" > &nbsp; </td>
                        <td align="center"><textarea name="87"  ></textarea></td>  
                    </tr>
                     <tr>
                        <td>Cara Pengisian</td>
                        <td align ='center'><input type="radio" value="1" name="88" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="88" > &nbsp; </td>
                        <td align="center"><textarea name="90"  ></textarea></td>  
                    </tr> 
                     <tr>
                        <td>Kurikulum</td>
                        <td align ='center'><input type="radio" value="1" name="91" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="91" > &nbsp; </td>
                        <td align="center"><textarea name="93"  ></textarea></td>  
                    </tr> 
                     <tr>
                        <td>Lainnya</td>
                        <td align ='center' colspan="5"><textarea name="94"   class="textarea form-control"></textarea></td>  
                    </tr> 
              

                </table>
           </div>
           </div>
           </div>
            </section><section class="content">
            <div class="col-md-12">
          <div class="box box-default collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title">A. Pengisian PDSS & SNMPTN 2017</h3></br><br>I. Sosialisasi PDSS & SNMPTN 2017</h3><br><br></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
               
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: none;">
              <div class="row">
                   <h2 class="box-title">5. Apakah terdapat sekolah yang mendaftar PDSS di tahun 2016 tetapi tidak mendaftar di tahun 2017. Apa yang terjadi penyebabnya?</h2>
            
         
                <textarea name="95"  class="textarea form-control"></textarea>
           
           
         </div>
         </div>
           </section><section class="content">
            <div class="col-md-12">
          <div class="box box-default collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title">A. Pengisian PDSS & SNMPTN 2017</h3></br><br>II. PORTFOLIO</h3><br><br></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
                
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: none;">
              <div class="row">
              
            
           <h2 class="box-title" >&nbsp;&nbsp;&nbsp;1. Apakah PTN saudara memiliki fakultas / program studi seni & olahraga?</h2>
            
            
                <table class="table table-bordered">
                    <tr>
                    <td align='center' colspan="1" rowspan="2">Program Studi</td>
                    <td rowspan="1" colspan="8" align="center">Aspek </td>
                    </tr>
                    <tr>
                        <td align="center">Ada</td>
                        <td align="center">Tidak Ada</td>
                        <td align="center">Masukan penting dari peserta selama sosialisasi portofolio berlangsung</td>
                        
                    </tr>
                    <tr>
                        <td>Keolahragaan </td>
                        <td align ='center'><input type="radio" value="1" name="96" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="96" > &nbsp; </td>
                       
                        <td align="center"><textarea name="98"  ></textarea></td>     
                    </tr>
                    
                    <tr>
                        <td>Seni</td>
                        <td align ='center'><input type="radio" value="1" name="100" > &nbsp; </td>
                        <td align ='center'><input type="radio" value="1" name="100" > &nbsp; </td>
                       
                        <td align="center"><textarea name="101"  ></textarea></td>  
                    </tr>
                </table>
           
            </div>
            <!-- /.box-body -->
          </div>
        </section><section class="content">
            <div class="col-md-12">
          <div class="box box-default collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title">A. Pengisian PDSS & SNMPTN 2017</h3></br><br>III. PENDAFTARAN SNMPTN</h3><br><br></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
                
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: none;">
              <div class="row">
              
          
           <h2 class="box-title" align="center">1. Tuliskan masukan penting dari Sasaran selama sosialisasi Pendaftaran SNMPTN ?</h2>
            
            
                <table class="table table-bordered">
                    <tr>
                    <td align='center' colspan="1" rowspan="2">Sasaran</td>
                    <td rowspan="1" colspan="8" align="center">Aspek </td>
                    </tr>
                    <tr>MASUKAN PENTING</td>
                        
                    </tr>
                    <tr>
                        <td>Siswa </td>
                        <td align="center"><textarea name="102"  class="textarea form-control" ></textarea></td>     
                    </tr>
                    
                    <tr>
                        <td>Guru (BK)</td>
                        <td align="center"><textarea name="103"  class="textarea form-control"></textarea></td>  
                    </tr>
                    <tr>
                        <td>Kepala Sekolah</td>
                        <td align="center"><textarea name="104"  class="textarea form-control"></textarea></td>  
                    </tr>
                    <tr>
                        <td>Orang tua Siswa</td>
                        <td align="center"><textarea name="105"  class="textarea form-control"></textarea></td>  
                    </tr>
                </table>
           
            </div>
            <!-- /.box-body -->
          </div>
        </section>
        <section class="content">
            <div class="col-md-12">
          <div class="box box-default collapsed-box">
            <div class="box-header with-border">
              <h3 class="box-title">B. MASUKAN TERPENTING</h3></br><br>I. Sosialisasi PDSS & SNMPTN 2017</h3><br><br></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
                
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: none;">
              <div class="row">
                   <h2 class="box-title"></h3></br><br>
              
           
           <h2 class="box-title" align="center">Tuliskan 3 (tiga) masukan terpenting terkait dengan kegiatan<br>sosialisasi PDSS dan SNMPTN ?</h2>
            
          
                <table class="table table-bordered">
                    
                    <tr>MASUKAN PENTING</td>
                        
                    </tr>
                    <tr>
                        <td>1 </td>
                        <td align="center"><textarea name="106"  class="textarea form-control"></textarea></td>     
                    </tr>
                    
                    <tr>
                        <td>2</td>
                        <td align="center"><textarea name="107"  class="textarea form-control"></textarea></td>  
                    </tr>
                    <tr>
                        <td>3</td>
                        <td align="center"><textarea name="108"  class="textarea form-control"></textarea></td>  
                    </tr>
                </table>
            </div>
            <!-- /.box-body -->
          </div>
          </div>
                <center><input type="submit" name="submit" class="btn btn-success btn-block" align="center">
           </form>

        </section>
        <!-- /.content -->
        
