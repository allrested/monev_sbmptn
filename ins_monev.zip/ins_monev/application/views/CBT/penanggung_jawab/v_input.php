 <section class="content-header">
            <h1>
                QUISIONER SBMPTN 2017
                <small></small>
            </h1>
        </section>

        <!-- Main content -->
        <section class="content">
        <div class="col-md-12">
          <div class="box box-default">
            <div class="box-header with-border">
              <h4 class="box-title"></h3><br><br></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
              <h3 class="box-title">Penanggung Jawab Ruang Ujian dimohon bantuannya untuk menjawab setiap pertanyaan dengan cara mengisi jumlah pada kolom jawaban yang sesuai disertai uraian/penjelasan atas jawaban tersebut. <h3>
            <form method="post" action="<?php echo base_url()?>CBT/Penanggung_jawab_insert">
            <table class="table table-bordered" >
                <thead>
                    <tr>
                        <td align="center" rowspan="2">No</td>
                        <td align="center" rowspan="2">Pertanyaan</td>
                        <td align="center" colspan="2" rowspan="1">Jawaban</td>
                        <td align="center" colspan="2" rowspan="2">Berikan Penjelasan Jika Jawaban ‘Tidak’</td>
                    </tr><tr>
                        <td align="center" rowspan="1">Ya</td>
                        <td align="center" rowspan="1">Tidak</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td align="center">1</td>
                        <td>Apakah Album Bukti Hadir Peserta (ABHP) disusun per dua puluhan ?</td>
                        <td align="center"><input type="number" class="form-control" name="1y" ></td>
                        <td align="center"><input type="number" class="form-control" name="1n" ></td>
                        <td align="center"><input type="text" name="1t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    <tr>
                        <td align="center">2</td>
                        <td>Apakah Saudara menerima surat tugas ?</td>
                        <td align="center"><input type="number" class="form-control" name="2y" ></td>
                        <td align="center"><input type="number" class="form-control" name="2n" ></td>
                        <td align="center"><input type="text" name="2t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    <tr>
                        <td align="center">3</td>
                        <td>Apakah Anda diminta mengisi Surat Pernyataan Penanggungjawab Lokasi Pelaksanan CBT (SPU02C) ?</td>
                        <td align="center"><input type="number" class="form-control" name="3y" ></td>
                        <td align="center"><input type="number" class="form-control" name="3n" ></td>
                        <td align="center"><input type="text" name="3t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    <tr>
                        <td align="center">4</td>
                        <td>Apakah Anda mengikuti pengarahan/pembekalan dari Panlok sebelum pelaksanaan ujian?</td>
                        <td align="center"><input type="number" class="form-control" name="4y" ></td>
                        <td align="center"><input type="number" class="form-control" name="4n" ></td>
                        <td align="center"><input type="text" name="4t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    <tr>
                        <td align="center">5</td>
                        <td>Apakah Anda menyaksikan instalsi dokumen ujian ke server lokal yang dilakukan oleh tim IT CBT Panitia Pusat disertai Berita Acara BA.N2C ? </td>
                        <td align="center"><input type="number" class="form-control" name="5y" ></td>
                        <td align="center"><input type="number" class="form-control" name="5n" ></td>
                        <td align="center"><input type="text" name="5t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    <tr>
                        <td align="center">6</td>
                        <td>Apakah Anda mengisi BA.U2C. baik ada pelanggaran maupun tidak ada pelanggaran?</td>
                        <td align="center"><input type="number" class="form-control" name="6y" ></td>
                        <td align="center"><input type="number" class="form-control" name="6n" ></td>
                        <td align="center"><input type="text" name="6t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    <tr>
                        <td align="center">7</td>
                        <td>Jika ada peserta yang tidak hadir pada saat ujian, kursi dengan nomor ujian peserta yang tidak hadir tersebut tetap Anda kosongkan ?</td>
                        <td align="center"><input type="number" class="form-control" name="7y" ></td>
                        <td align="center"><input type="number" class="form-control" name="7n" ></td>
                        <td align="center"><input type="text" name="7t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    <tr>
                        <td align="center">8</td>
                        <td>Apakah Anda mencocokkan tandatangan peserta dalam Album Bukti Hadir Peserta (ABHP) dengan tandatangan peserta pada Kartu Tanda Peserta atau Kartu Identitas Diri ?</td>
                        <td align="center"><input type="number" class="form-control" name="8y" ></td>
                        <td align="center"><input type="number" class="form-control" name="8n" ></td>
                        <td align="center"><input type="text" name="8t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    <tr>
                        <td align="center">9</td>
                        <td>Jika ada peserta yang terlambat masuk lebih dari tiga puluh menit, apakah Anda melarang untuk mengikuti ujian?</td>
                        <td align="center"><input type="number" class="form-control" name="9y" ></td>
                        <td align="center"><input type="number" class="form-control" name="9n" ></td>
                        <td align="center"><input type="text" name="9t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    <tr>
                        <td align="center">10</td>
                        <td>Apakah Anda menyaksikan pengiriman (upload) Jawaban Ujian dari server lokal dengan menggunakan Berita Acara BA.J1C ?</td>
                        <td align="center"><input type="number" class="form-control" name="10y" ></td>
                        <td align="center"><input type="number" class="form-control" name="10n" ></td>
                        <td align="center"><input type="text" name="10t" class="form-control">
                    <a href="#" id="ttip_id_lokasi" data-toggle="tooltip" title="" lokasi="" ujian""="" data-original-title="?">
          <span class="fa fa-question-circle"></span></a></td></tr>
                    
                </tbody>
            </table>
            <center><button type="submit" class="btn btn-success"  <?php if($this->session->userdata('logged_admin')) { echo "style='display:none'";}?>>Submit</button></center>
            </form>
            </div>
            </div>
        </div>
        </section>